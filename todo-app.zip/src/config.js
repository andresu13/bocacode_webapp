export const firebaseConfig = {
  apiKey: "AIzaSyAdYCgyMnq2oa-DOz11V04SMWv-MJXJiRs",
  authDomain: "todo-too.firebaseapp.com",
  projectId: "todo-too",
  storageBucket: "todo-too.appspot.com",
  messagingSenderId: "88367278813",
  appId: "1:88367278813:web:4cc0aa7570226bb33a8934"
}
